var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/harman', function(req, res, next) {
  res.render('harman', { title: 'Express' });
});

router.get('/harpal', function(req, res, next) {
  res.render('harpal', { title: 'Express' });
});

router.get('/sukhman', function(req, res, next) {
  res.render('sukhman', { title: 'Express' });
});

router.get('/rupinder', function(req, res, next) {
  res.render('rupinder', { title: 'Express' });
});

router.get('/noor', function(req, res, next) {
  res.render('noor', { title: 'Express' });
});

module.exports = router;
